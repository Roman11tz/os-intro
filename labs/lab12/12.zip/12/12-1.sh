
#!/bin/bash
cd /usr/share/man/man1
less $1*
